# EMAIL LOGIN & LOGOUT x FIREBASE

Watch tutorial here: https://youtu.be/_3W-JuIVFlg

![71BB3DCC-2536-40CE-A9E4-966C8FCE5ED4](https://user-images.githubusercontent.com/29016489/208593637-b45d7a7f-f421-4663-b017-9f158963d0ce.JPG)
